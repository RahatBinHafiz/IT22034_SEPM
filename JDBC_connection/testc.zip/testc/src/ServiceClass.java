import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceClass extends MyDBClass {

    public boolean InsertDB(String name) {
        this.connection = getConnection();
        String sql = "INSERT INTO students(name) VALUES(?)";  // table name updated

        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, name);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeAll();
        }
        return false;
    }

    public List<Student> ReadFromDB() {
        List<Student> list = new ArrayList<>();
        this.connection = getConnection();
        String sql = "SELECT id, name FROM students";  // table name updated

        try {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Student std = new Student();
                std.setId(rs.getInt("id"));
                std.setName(rs.getString("name"));
                list.add(std);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeAll();
        }
        return list;
    }
}
