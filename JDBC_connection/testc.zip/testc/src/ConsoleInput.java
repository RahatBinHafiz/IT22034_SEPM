import java.util.List;
import java.util.Scanner;

public class ConsoleInput {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ServiceClass serviceClass = new ServiceClass();

        System.out.print("Name: ");
        String name = scanner.nextLine();

        boolean inserted = serviceClass.InsertDB(name);
        System.out.println(inserted ? "Student inserted!" : "Insert failed.");

        List<Student> students = serviceClass.ReadFromDB();
        if (students != null && !students.isEmpty()) {
            System.out.println("All Students:");
            for (Student s : students) {
                System.out.println(s.getId() + " " + s.getName());
            }
        } else {
            System.out.println("No students found.");
        }
    }
}
